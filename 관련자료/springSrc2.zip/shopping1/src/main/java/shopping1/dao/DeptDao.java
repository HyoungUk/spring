package shopping1.dao;

import java.util.List;

import shopping1.model.Dept;

public interface DeptDao {

	List<Dept> list();

}
