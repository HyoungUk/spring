package shopping1.service;
import java.util.List;
import shopping1.model.Dept;
public interface DeptService {
	List<Dept> list();

}