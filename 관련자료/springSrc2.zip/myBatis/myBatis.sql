select * from emp;
select * FROM DEPT ORDER BY DEPTNO;
select * from emp e, dept d where e.deptno=d.deptno