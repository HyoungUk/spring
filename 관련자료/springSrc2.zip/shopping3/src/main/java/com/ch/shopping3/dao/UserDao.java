package com.ch.shopping3.dao;
import com.ch.shopping3.model.User;
public interface UserDao {
	User loginChk(String userId);

}