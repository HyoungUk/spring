package com.ch.shopping3.dao;
import com.ch.shopping3.model.Member;
public interface MemberDao {
	Member loginChk(String id);

}