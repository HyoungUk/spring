package com.ch.shopping3.service;
import com.ch.shopping3.model.Member;
public interface MemberService {

	Member loginChk(String id);

}