package com.ch.shopping3.service;
import com.ch.shopping3.model.User;
public interface UserService {
	User loginChk(String userId);

}