create table person (
	id varchar2(10) primary key,
	name varchar2(12)
)
select * from person;
delete from person;