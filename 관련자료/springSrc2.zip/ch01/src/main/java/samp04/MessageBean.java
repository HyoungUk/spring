package samp04;
public interface MessageBean {
	void sayHello();
}