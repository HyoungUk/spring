package samp07;

public interface Vehicle {
	void ride();
}