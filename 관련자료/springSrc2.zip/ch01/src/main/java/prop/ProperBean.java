package prop;
import java.util.Properties;
public class ProperBean {
	private Properties ppt;
	public Properties getPpt() {
		return ppt;
	}
	public void setPpt(Properties ppt) {
		this.ppt = ppt;
	}	
}