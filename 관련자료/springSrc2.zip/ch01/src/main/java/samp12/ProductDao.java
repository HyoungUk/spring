package samp12;

public interface ProductDao {
	Product getProduct(String title);
}