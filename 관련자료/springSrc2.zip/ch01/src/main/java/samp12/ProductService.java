package samp12;
public interface ProductService {
	Product getProduct();
}