package samp15.service;

import samp15.model.Book;

public interface BookService {
	Book getBook();
}