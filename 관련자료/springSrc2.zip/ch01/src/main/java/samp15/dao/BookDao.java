package samp15.dao;

import samp15.model.Book;

public interface BookDao {
	Book getBook(String title);
}
