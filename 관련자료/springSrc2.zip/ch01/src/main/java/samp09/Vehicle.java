package samp09;
public interface Vehicle {
	void ride(); // public abstract
}