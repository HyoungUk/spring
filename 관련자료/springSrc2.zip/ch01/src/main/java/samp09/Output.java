package samp09;
public interface Output {
	void write(String msg);
}