package samp02;
public class Ex01 {
	public static void main(String[] args) {
		// MessageBean mb = new MessageBeanKr();
		MessageBean mb = new MessageBeanEn();
		mb.sayHello("이승기");
	}
}