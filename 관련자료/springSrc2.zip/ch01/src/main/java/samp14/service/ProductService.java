package samp14.service;
import samp14.model.Product;
public interface ProductService {
	Product getProduct();
}