package samp14.dao;
import samp14.model.Product;
public interface ProductDao {
	Product getProduct(String name);
}