package samp11;

public interface BookService {
	Book getBook();
}