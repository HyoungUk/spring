package samp03;
public interface MessageBean {
	public void sayHello(String name);
}