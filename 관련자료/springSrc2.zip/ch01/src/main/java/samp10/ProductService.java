package samp10;
public interface ProductService {
	Product getProduct();
}