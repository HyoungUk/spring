package samp10;
public interface ProductDao {
	public Product getProduct(String name);
}