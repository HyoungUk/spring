package samp06;
public interface MessageBean {
	void sayHello();
}