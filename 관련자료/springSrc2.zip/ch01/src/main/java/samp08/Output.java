package samp08;
public interface Output {
	void print(String msg);
}