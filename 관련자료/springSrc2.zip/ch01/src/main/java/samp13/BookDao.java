package samp13;

public interface BookDao {
	Book getBook(String title);
}