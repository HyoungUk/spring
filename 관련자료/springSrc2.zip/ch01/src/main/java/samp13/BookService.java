package samp13;

public interface BookService {
	Book getBook();
}