package samp05;
public interface Vehicle {
	void ride();
}