package samp01;
public class Ex01 {
	public static void main(String[] args) {
		// MessageBeanKo mb = new MessageBeanKo();
		MessageBeanEn mb = new MessageBeanEn();
		mb.sayHello("최순실");
	}
}