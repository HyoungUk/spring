package samp05;
public interface ProductService {
	Product getProduct();
}