package samp05;

public interface ProductDao {
	Product getProduct(String name);
}