package samp03;
public interface MessageBean {
	void sayHello(String name);
}