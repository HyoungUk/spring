package samp06;
public interface ProductService {
	Product getProduct();
}