package samp06;

public interface ProductDao {
	Product getProduct(String name);
}