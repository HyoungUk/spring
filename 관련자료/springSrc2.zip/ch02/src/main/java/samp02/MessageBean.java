package samp02;
public interface MessageBean {
	void sayHello(String name);
}