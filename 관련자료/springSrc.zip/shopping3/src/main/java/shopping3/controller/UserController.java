package shopping3.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import shopping3.model.User;
import shopping3.service.UserService;
@Controller
public class UserController {
	@Autowired
	private UserService us;
	@Autowired
	private Validator uv;
	@ModelAttribute
	public User bind() {
		return new User();
	}
	@RequestMapping(value="userLogin",method=RequestMethod.GET)
	public String userLoginForm() {
		return "userLogin";
	}
	@RequestMapping(value="userLogin", method=RequestMethod.POST)
	public ModelAndView userLogin(User user, BindingResult br) {
		ModelAndView mav = new ModelAndView();
		uv.validate(user, br);
		if (br.hasErrors()) {
			mav.getModel().putAll(br.getModel());
			return mav;
		}
		try {
			User ur = us.userCheck(user.getUserId(),user.getPassword());
			mav.addObject("user", ur);
			mav.setViewName("userSuccess");
		}catch(Exception e) {
			br.reject("error.login.user");
			mav.getModel().putAll(br.getModel());
		}
		return mav;
	}
	@RequestMapping(value="userLogin2",method=RequestMethod.GET)
	public String userLoginForm2() {
		return "userLogin2";
	}
	@RequestMapping(value="userLogin2", method=RequestMethod.POST)
	public String userLogin2(User user, Model model) {
		try {
			User ur = us.userCheck(user.getUserId(),user.getPassword());
			model.addAttribute("user", ur);
			return "userSuccess";
		}catch(Exception e) {
			model.addAttribute("msg", "똑바로 해");
			model.addAttribute("user", user);
		}
		return "userLogin2";
	}
}