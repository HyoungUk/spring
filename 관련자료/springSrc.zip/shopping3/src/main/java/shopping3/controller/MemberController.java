package shopping3.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import shopping3.model.Member;
import shopping3.service.MemberService;
@Controller
public class MemberController {
	@Autowired
	MemberService ms;
	@Autowired
	Validator mv;
	@ModelAttribute
	public Member bind() {
		return new Member();
	}
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String loginForm() {
		return "login";
	}
	@RequestMapping(value="login",method=RequestMethod.POST)
	public ModelAndView login(Member member, BindingResult br) {
		ModelAndView mav = new ModelAndView();
		mv.validate(member, br);
		if (br.hasErrors()) {
			mav.getModel().putAll(br.getModel());
			return mav;
		}
		try {
			Member mem = 
				ms.loinCheck(member.getId(),member.getPassword());
			mav.addObject("member",mem);
			mav.setViewName("loginSuccess");
		} catch(Exception e) {
			br.reject("error.login.member");
			mav.getModel().putAll(br.getModel());
		}
		return mav;
	}
	@RequestMapping(value="login2",method=RequestMethod.GET)
	public String loginForm2() {
		return "login2";
	}
	@RequestMapping(value="login2",method=RequestMethod.POST)
	public String login2(Member member, Model model) {
		Member mem = null;
		try {
			mem=ms.loinCheck(member.getId(),member.getPassword());
			model.addAttribute("member",mem);
			return "loginSuccess";
		} catch(Exception e) {
			model.addAttribute("member",member);
			model.addAttribute("message","암호/아이디 확인해봐");
		}
		return "login2";
	}
}