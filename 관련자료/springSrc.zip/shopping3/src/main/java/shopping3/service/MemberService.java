package shopping3.service;
import shopping3.model.Member;
public interface MemberService {
	Member loinCheck(String id, String password);

}