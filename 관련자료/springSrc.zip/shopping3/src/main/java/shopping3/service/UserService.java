package shopping3.service;
import shopping3.model.User;
public interface UserService {
	User userCheck(String userId, String password);
}
