package shopping3.service;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import shopping3.model.Member;
@Component("mv")
public class MemberValidate implements Validator {
	public boolean supports(Class<?> arg0) {
		return false;
	}
	public void validate(Object obj, Errors err) {
		Member member = (Member)obj;
		if (!StringUtils.hasLength(member.getId())) {
			err.rejectValue("id", "error.required");
		}
		if (!StringUtils.hasLength(member.getPassword())) {
			err.rejectValue("password", "error.required");
		}
		if (err.hasErrors()) {
			err.reject("error.input.member");
		}
	}
}