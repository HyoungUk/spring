package shopping3.dao;
import shopping3.model.User;
public interface UserDao {
	User userCheck(String userId, String password);

}