package shopping3.dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import shopping3.model.User;
@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	private JdbcTemplate jt;
	public User userCheck(String userId, String password) {
		String sql = "select * from user1 where userId=? and password=?";
		User user = jt.queryForObject(sql,
			new BeanPropertyRowMapper<User>(User.class),
			userId,password);
		return user;
	}
}