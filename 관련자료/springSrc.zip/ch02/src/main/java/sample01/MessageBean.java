package sample01;
public interface MessageBean {
	void sayHello();
}