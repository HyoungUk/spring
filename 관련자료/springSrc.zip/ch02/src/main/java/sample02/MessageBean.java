package sample02;
public interface MessageBean {
	void sayHello();
}