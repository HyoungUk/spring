package sample02;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.util.StopWatch;
public class LoggingAdvice implements MethodInterceptor{
	public Object invoke(MethodInvocation mi) throws Throwable {
		String methodName = mi.getMethod().getName();
		System.out.println("메소드명 : "+methodName+" 시작");
		StopWatch sw = new StopWatch();
		sw.start(methodName);
		Object obj = mi.proceed();
		sw.stop();
		System.out.println("작업 끝 작업시간 : " +
				sw.getTotalTimeSeconds()+"초");
		return obj;
	} 
}