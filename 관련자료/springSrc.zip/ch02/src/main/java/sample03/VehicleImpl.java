package sample03;
public class VehicleImpl  implements Vehicle {
	private String name;
	private String rider;	
	public void setName(String name) {
		this.name = name;
	}
	public void setRider(String rider) {
		this.rider = rider;
	}
	public void ride() {
		try {	Thread.sleep(2000);
		} catch (InterruptedException e) {}
		System.out.println(name+"(이)가 "+rider+"를 탄다");
	}
}