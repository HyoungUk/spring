package sample03;
public interface Vehicle {
	void ride();
}