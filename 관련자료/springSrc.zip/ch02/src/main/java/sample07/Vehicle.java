package sample07;

public interface Vehicle {
	void ride();
}