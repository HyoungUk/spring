package sample06;
public interface MessageBean {
	void sayHello();
}