package sample08;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
public class MyAspect {
	public void before(JoinPoint jp) {
		Signature sig = jp.getSignature();
		System.out.println("before "+sig.getName());
	}
	public void after() {
		System.out.println("after");
	}
	public void afterReturn(JoinPoint jp, Product product) {
		System.out.println("afterReturn : "+ product);
	}
	public void afterThru(Throwable e) {
		System.out.println("afterThru");
	}
	public Object around(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("around 앞");
		Object obj = pjp.proceed();
		System.out.println("around 뒤");
		return obj;
	}	
}