package sample08;
public interface ProductService {
	Product getProduct();
}