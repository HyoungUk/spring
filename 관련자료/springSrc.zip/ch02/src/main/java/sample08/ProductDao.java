package sample08;
public interface ProductDao {
	Product getProduct(String name);
}