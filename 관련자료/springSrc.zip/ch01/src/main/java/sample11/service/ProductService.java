package sample11.service;
import sample11.model.Product;
public interface ProductService {
	Product getProduct();
}