package sample06;

public interface Vehicle {
	void ride();	
}