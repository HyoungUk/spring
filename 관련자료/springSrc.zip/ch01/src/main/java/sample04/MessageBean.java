package sample04;
public interface MessageBean {
	void sayHello();
}