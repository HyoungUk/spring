package sample01;

public class Ex01 {
	public static void main(String[] args) {
//		MessageBean mb = new MessageBean();
		MessageBeanKr mb = new MessageBeanKr();
		mb.sayHello("Spring");
	}
}