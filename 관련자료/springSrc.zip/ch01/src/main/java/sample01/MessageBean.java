package sample01;

public class MessageBean {
	void sayHello(String name) {
		System.out.println("Hello! "+name);
	}
}