package sample05;

public interface Vehicle {
	void ride(String name);
}