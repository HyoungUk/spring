package sample05;
public class Airplane  implements Vehicle {
	public void ride(String name) {
		System.out.println(name+"(이)가 비행기를 탄다");
	}
}