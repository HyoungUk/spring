package sample10;
public interface Vehicle {
	void rider();
}