package sample10;
public interface Outputer {
	void output(String msg);
}