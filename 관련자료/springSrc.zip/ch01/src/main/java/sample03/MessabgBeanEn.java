package sample03;
public class MessabgBeanEn implements MessageBean {
	public void sayHello(String name) {
		System.out.println("Hello ! "+name);		
	}	
}