package sample15;
public interface BookDao {
	Book getBook(String title);
}