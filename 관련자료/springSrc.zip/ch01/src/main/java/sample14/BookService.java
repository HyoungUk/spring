package sample14;
public interface BookService {
	Book getBook();
}