package sample13;
public interface ProductService {
	Product getProduct();
}