package sample09;
public interface MessageBean {
	void sayHello();
}