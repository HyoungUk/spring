package sample02;
public class Ex01 {
	public static void main(String[] args) {
//		MessageBean mb = new MessageBeanEn();
		MessageBean mb = new MessageBeanKr();
		mb.sayHello("Spring");
	}
}