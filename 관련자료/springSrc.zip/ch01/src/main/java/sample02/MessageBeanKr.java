package sample02;
public class MessageBeanKr implements MessageBean {
	public void sayHello(String name) {
		System.out.println("안녕하세요! "+name);		
	}	
}