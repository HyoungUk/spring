package utils;
public class WebConstants {
	public static final String USER_KEY = "USER_KEY";	
	public static final String CART_KEY = "CART_KEY";
}