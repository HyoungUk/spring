package dao;

import logic.SaleLine;

public interface SaleLineDao {
	public void create(SaleLine saleLine);
}
