package shopping1.service;
import java.util.List;
import shopping1.model.Dept;
import shopping1.model.Item;
public interface ItemService {
	List<Item> list();
	List<Dept> deptList();

}