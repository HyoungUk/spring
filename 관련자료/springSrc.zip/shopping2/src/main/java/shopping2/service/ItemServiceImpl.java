package shopping2.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import shopping2.dao.DeptDao;
import shopping2.dao.ItemDao;
import shopping2.model.Dept;
import shopping2.model.Emp;
import shopping2.model.Item;
@Service
public class ItemServiceImpl implements ItemService {
	@Autowired
	private ItemDao id;
	@Autowired
	private DeptDao dd;
	public List<Item> list() {
		return id.list();
	}
	public Item select(int itemId) {
		return id.select(itemId);
	}
	public List<Dept> deptList() {
		return dd.deptList();
	}
	public List<Emp> empList(int deptno) {
		return dd.empList(deptno);
	}
}