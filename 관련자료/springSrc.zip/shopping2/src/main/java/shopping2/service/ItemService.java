package shopping2.service;
import java.util.List;

import shopping2.model.Dept;
import shopping2.model.Emp;
import shopping2.model.Item;
public interface ItemService {
	List<Item> list();
	Item select(int itemId);
	List<Dept> deptList();
	List<Emp> empList(int deptno);

}