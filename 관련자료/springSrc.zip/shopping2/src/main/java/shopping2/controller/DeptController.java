package shopping2.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import shopping2.model.Dept;
import shopping2.model.Emp;
import shopping2.service.ItemService;
@Controller
public class DeptController {
	@Autowired
	private ItemService is;
	@RequestMapping("dept")
	public String deptList(Model model) {
		List<Dept> list = is.deptList();
		model.addAttribute("deptList", list);
		return "deptList";
	}
	@RequestMapping("emp")
	public String empList(int deptno, Model model) {
		List<Emp> empList = is.empList(deptno);
		model.addAttribute("empList", empList);
		return "empList";
	}
}