package shopping2.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import shopping2.model.Dept;
import shopping2.model.Emp;
@Repository
public class DeptDaoImpl implements DeptDao {
	@Autowired
	private JdbcTemplate jt;
	public List<Dept> deptList() {
		List<Dept> list = jt.query("select * from dept",
			new BeanPropertyRowMapper<Dept>(Dept.class));
		return list;
	}
	public List<Emp> empList(int deptno) {
		List<Emp> list = jt.query(
			"select * from emp where deptno=?",
			new BeanPropertyRowMapper<Emp>(Emp.class),deptno);
		return list;
	}	
}