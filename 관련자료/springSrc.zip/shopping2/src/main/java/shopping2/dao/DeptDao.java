package shopping2.dao;
import java.util.List;
import shopping2.model.Dept;
import shopping2.model.Emp;
public interface DeptDao {
	List<Dept> deptList();
	List<Emp> empList(int deptno);

}