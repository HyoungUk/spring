package shopping2.dao;
import java.util.List;
import shopping2.model.Item;
public interface ItemDao {
	List<Item> list();
	Item select(int itemId);

}
