package shopping4.service;
import shopping4.model.User;
public interface UserService {
	void insert(User user);

}