package shopping4.dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import shopping4.model.User;
@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	private JdbcTemplate jt;
	public void insert(User user) {
		String sql="insert into user1 values(?,?,?,?,?,?,?,?)";
		jt.update(sql,user.getUserId(),user.getUserName(),
			user.getPassword(),user.getPostCode(),user.getAddress(),
			user.getEmail(),user.getJob(),user.getBirthday());
	}
}