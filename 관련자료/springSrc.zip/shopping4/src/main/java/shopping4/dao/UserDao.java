package shopping4.dao;
import shopping4.model.User;
public interface UserDao {
	void insert(User user);

}