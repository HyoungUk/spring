package iBatis1.dao;
import iBatis1.model.Member;
public interface MemberDao {
	Member select(String id);
	int insert(Member member);

}